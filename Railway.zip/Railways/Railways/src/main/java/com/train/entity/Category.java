package com.train.entity;

public enum Category {

	EXPRESS, SHATABDI, METRO
}
