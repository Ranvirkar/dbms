package com.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.train.entity.Railway;

public interface RailwayRepository extends JpaRepository<Railway, Long> {


	 
 
}

