package com.blogs.Entity;

public enum Category {
EXPRESS,SHATABDI,AC,METRO;
}
