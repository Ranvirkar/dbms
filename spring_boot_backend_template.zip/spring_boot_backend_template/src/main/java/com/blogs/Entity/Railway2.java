package com.blogs.Entity;

public class Railway2 {

}
