package com.blogs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blogs.Entity.Railway;

public interface Railwayrepository extends JpaRepository<Railway,Long> {

}
